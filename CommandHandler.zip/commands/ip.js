exports.run = (client, message, args, config) => {
    var index = require("../index")
    message.channel.send("Play.VortexPvP.eu")
  };