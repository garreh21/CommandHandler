exports.run = (client, message, args, config) => {
    var index = require("../index")

    message.channel.send("1.11.2")
};